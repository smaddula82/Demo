from ensurepip import bootstrap
from kafka import KafkaProducer
import json
from data import get_registered_user
import time

# Define a method to get the data
def json_serializer(data):
    return json.dumps(data).encode('utf-8')    #Serializing the data and encoding it in redable format

def get_partition(key, all, available):
    return 0                                   #Return the values only to partition-0

producer = KafkaProducer(bootstrap_servers = ['192.168.29.79:9092'],   #broker
                         value_serializer = json_serializer,            #Data serializer for communication
                         partitioner = get_partition)                  #Setting it to desired partition

if __name__ == '__main__':
    while 1 == 1:
        registered_user = get_registered_user()
        print(registered_user)
        producer.send('registered_user', registered_user)        # send the data along with the topic name created in the kafka manager
                                                        # (name should be same) to the single partition created
        time.sleep(5)