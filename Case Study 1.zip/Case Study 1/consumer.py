from kafka import KafkaConsumer
import json


if __name__ == '__main__':
    consumer = KafkaConsumer(
        'registered_user',                        # Topic Name
        bootstrap_servers = '192.168.29.79:9092',  # Connecting to kafka server
        auto_offset_reset = 'earliest',           # This makes helps the consumer to know when can it 
                                                  # consume the topic(start or end) 
        group_id = 'consumer-group-a')             # group_id for the consumer

    print('Strating the conusmer')

    for msg in consumer:
        print('Registered_User = {}'.format(json.loads(msg.value)))   # json.loads - de-serialize the data     
    